<img src="artwork/OASIS-Primary-Logo-Full-Colour.png" width="200">

# IPR Statement

OASIS is not aware of any statements or declarations regarding IPR related to the work of this Open Project.

OASIS invites any persons who know of any such claims to disclose these if they may be essential to the implementation of works published by this project. Please send any such notice to the [Open Projects Administrator](mailto:op-admin@oasis-open.org), so that they may be posted here.

