# CACAO Playbook Examples

In the near future this folder will contain few CACAO Playbooks that can be imported to the CACAO Roaster to better understand its capabilities.

Check the official OASIS CACAO TC GitHub for more examples: https://github.com/oasis-tcs/cacao/tree/master/Examples/CACAO-2.0.
