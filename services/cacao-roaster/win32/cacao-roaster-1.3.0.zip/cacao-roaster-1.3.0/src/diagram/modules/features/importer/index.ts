import CacaoImporter from './CacaoImporter';

export default {
  __init__: ['cacaoImporter'],
  cacaoImporter: ['type', CacaoImporter],
};
