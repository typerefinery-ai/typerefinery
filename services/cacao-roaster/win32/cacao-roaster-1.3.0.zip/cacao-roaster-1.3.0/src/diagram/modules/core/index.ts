import RendererModule from '../draw';

export default {
  __depends__: [RendererModule],
};
