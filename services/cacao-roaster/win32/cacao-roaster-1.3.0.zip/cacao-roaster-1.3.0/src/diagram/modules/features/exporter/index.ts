import CacaoExporter from './CacaoExporter';

export default {
  __init__: ['cacaoExporter'],
  cacaoExporter: ['type', CacaoExporter],
};
