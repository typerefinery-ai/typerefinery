import CacaoRenderer from './CacaoRenderer';

export default {
  __init__: ['cacaoRenderer'],
  cacaoRenderer: ['type', CacaoRenderer],
};
