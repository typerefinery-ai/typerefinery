import IntegrationLogWindow from './IntegrationLogWindow';

export default {
	__init__: ['integrationLogWindow'],
	integrationLogWindow: ['type', IntegrationLogWindow],
};
