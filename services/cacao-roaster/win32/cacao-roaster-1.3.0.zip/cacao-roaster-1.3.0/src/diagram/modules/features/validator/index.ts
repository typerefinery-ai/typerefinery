import CacaoValidator from './CacaoValidator';

export default {
  __init__: ['cacaoValidator'],
  cacaoValidator: ['type', CacaoValidator],
};
