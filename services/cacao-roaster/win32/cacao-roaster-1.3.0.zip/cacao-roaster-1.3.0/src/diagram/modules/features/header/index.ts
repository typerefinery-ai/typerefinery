import CacaoHeader from './CacaoHeader';

export default {
  __init__: ['cacaoHeader'],
  cacaoHeader: ['type', CacaoHeader],
};
