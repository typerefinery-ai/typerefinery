declare module 'diagram-js-minimap';
