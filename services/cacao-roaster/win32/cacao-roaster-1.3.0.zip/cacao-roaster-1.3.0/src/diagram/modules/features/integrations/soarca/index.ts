import Soarca from './Soarca';

export default {
  __init__: ['cacaoHeader'],
  cacaoHeader: ['type', Soarca],
};
