declare module 'diagram-js-grid';
