import CacaoSidePanel from './CacaoSidePanel';

export default {
  __init__: ['cacaoSidePanel'],
  cacaoSidePanel: ['type', CacaoSidePanel],
};
