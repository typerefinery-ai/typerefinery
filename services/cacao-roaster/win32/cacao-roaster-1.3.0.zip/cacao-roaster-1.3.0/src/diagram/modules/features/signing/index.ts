import CacaoSigning from './CacaoSigning';

export default {
  __init__: ['cacaoSigning'],
  cacaoSigning: ['type', CacaoSigning],
};
