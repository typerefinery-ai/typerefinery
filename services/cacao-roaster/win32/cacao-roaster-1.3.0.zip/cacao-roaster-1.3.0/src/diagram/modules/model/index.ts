import PlaybookHandler from './PlaybookHandler';

export default {
  __init__: ['playbookHandler'],
  playbookHandler: ['type', PlaybookHandler],
};
