import CacaoRules from './CacaoRules';

export default {
  __init__: ['cacaoRules'],
  cacaoRules: ['type', CacaoRules],
};
